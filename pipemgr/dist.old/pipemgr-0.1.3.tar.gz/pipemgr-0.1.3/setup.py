# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.models']

package_data = \
{'': ['*'], 'src': ['templates/*']}

install_requires = \
['PyYAML>=6.0,<7.0', 'docopts>=0.6.1,<0.7.0']

entry_points = \
{'console_scripts': ['pipemgr = src.cli:cli']}

setup_kwargs = {
    'name': 'pipemgr',
    'version': '0.1.3',
    'description': 'Helps manage the book syncing pipeline',
    'long_description': None,
    'author': 'Tyler Nullmeier',
    'author_email': 'tylerzeromaster@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8',
}


setup(**setup_kwargs)
